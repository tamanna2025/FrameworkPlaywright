package org.optimus.base;

import org.optimus.utilities.ConfigLoader;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import com.microsoft.playwright.*;

import com.optimus.constants.MobileConstants;

public class BaseWebTest {
    protected Playwright playwright;
    protected Browser browser;
    protected Page page;
    protected String url;

    @BeforeMethod
    public void setUp() {
        String configPath = MobileConstants.PATH;
        playwright = Playwright.create();
        browser = playwright.chromium().launch(new BrowserType.LaunchOptions().setHeadless(false));
        page = browser.newPage();
        url = ConfigLoader.configLoader1(configPath, "url");
        page.setDefaultTimeout(60000);
        // Load the URL at the beginning of each test
        if (page != null && url != null) {
            page.navigate(url);
        }
    }

    @AfterMethod
    public void tearDown() {
        if (page != null) {
            page.close();
        }
        if (browser != null) {
            browser.close();
        }
        if (playwright != null) {
            playwright.close();
        }
    }
}
