package org.optimus.pages;


import com.microsoft.playwright.Page;
import com.optimus.constants.GlobalConstants;
import com.optimus.constants.MobileConstants;
import com.optimus.constants.SearchProductConstants;

import io.qameta.allure.Step;
import org.optimus.utilities.WebUI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SearchProduct {
	
	private static final Logger log = LoggerFactory.getLogger(SearchProduct.class);
    private final Page page;
    private WebUI webUi;
    
    public SearchProduct(Page page) {
    	this.page = page;
        this.webUi = new WebUI(page);
    }
    @Step("<ul><li>1. Redirect to 'Flipkart site'" + "<ul><li>2. Search for 'iphone 16 pro'"+ "<ul><li>3.Then click on selected 'iPhone Model'"
	        + "<ul><li>4.Add 'iPhone' to cart. "+ "<ul><li>5. Click on 'enter delivery pincode'"
			+ "<ul><li>6. Enter 'pincode' in placeholder." + "<ul><li>7. Click on 'submit' button"+"</ul>")
    public void mobileSelect(String pin, String itemName) {
    	log.info(MobileConstants.LOG_MSG_NAVIGATING);
    	webUi.clickPlaceholder(page, SearchProductConstants.SEARCH_PRODUCT_PLACEHOLDER);
    	webUi.fillPlaceholder(page, SearchProductConstants.SEARCH_PRODUCT_PLACEHOLDER,itemName);
        webUi.pressEnter(SearchProductConstants.SEARCH_PRODUCT_PLACEHOLDER);
        webUi.waitForTimeout(GlobalConstants.FIVE_SEC_WAIT);
        webUi.clickByText(page, SearchProductConstants.NEWEST_FIRST_TEXT);
        Page popupPage = webUi.waitForPopupAndClick(SearchProductConstants.IPHONE_XPATH);
		webUi.clickWebElement(popupPage.locator(MobileConstants.ADD_TO_CART_XPATH), MobileConstants.ADD_TO_CART_XPATH);
		webUi.clickWebElement(popupPage.locator(SearchProductConstants.ENTER_DELIVERY_PINCODE_XPATH), SearchProductConstants.ENTER_DELIVERY_PINCODE_XPATH);
		webUi.clickPlaceholder(popupPage, SearchProductConstants.ENTER_PINCODE_PLACEHOLDER);
		webUi.fillPlaceholder(popupPage, SearchProductConstants.ENTER_PINCODE_PLACEHOLDER, pin);
	    webUi.clickByText(popupPage, SearchProductConstants.SUBMIT_TEXT);
	    webUi.assertIsVisibleText(popupPage, SearchProductConstants.TARN_TARAN_TEXT);
	    webUi.assertIsVisibleText(popupPage,  SearchProductConstants.APPLE_IPHONE_TEXT);
	    }
}
