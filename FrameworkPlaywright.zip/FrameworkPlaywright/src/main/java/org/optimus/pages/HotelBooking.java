package org.optimus.pages;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.optimus.utilities.WebUI;

import com.microsoft.playwright.Page;
import com.optimus.constants.GlobalConstants;
import com.optimus.constants.HotelBookingConstants;
import com.optimus.constants.OutStationCabConstants;

import io.qameta.allure.Step;
public class HotelBooking {
	/**
     * public class for goibibo hotel for web in India
     */
	private static Logger log = LogManager.getLogger(HotelBooking.class);
	private final Page page;
    private WebUI webUi;

    public HotelBooking(Page page) {
        this.page = page;
        this.webUi = new WebUI(page); 
    }
	@Step("<ul><li>1. Redirect to 'Hotel booking'" + "<ul><li>2. Select 'Amritsar' location"
	        + "<ul><li>3.Click on 'SEARCH' button" + "+</ul>")
	public void hotelSelect(String hotelCity, String name, String lname, String email, String mobile){
	
        log.info(HotelBookingConstants.LOG_MSG_OPEN_SUCCESS);
        webUi.clickWebElement(OutStationCabConstants.CLOSE_XPATH);
        webUi.clickWebElement(HotelBookingConstants.HOTELS_XPATH);
        webUi.clickWebElement(HotelBookingConstants.INDIA_XPATH);
        webUi.clickAndFillText(page, HotelBookingConstants.SEARCH_CITY_XPATH, hotelCity);
        webUi.clickWebElement(HotelBookingConstants.DROP_SELECT_XPATH);
        webUi.clickWebElement(HotelBookingConstants.GUEST_ROOMS_XPATH);
        webUi.assertIsVisibleText(page, HotelBookingConstants.GUESTS_AND_ROOMS_TEXT);
        webUi.clickWebElement(HotelBookingConstants.ADD_ROOM_XPATH);
        webUi.clickWebElement(HotelBookingConstants.ADD_ADULT_XPATH);
        webUi.clickWebElement(HotelBookingConstants.ADD_CHILD_XPATH);
        webUi.clickWebElement(HotelBookingConstants.SELECT_XPATH);
        webUi.clickWebElement(HotelBookingConstants.CHILD_AGE_XPATH);
        webUi.clickWebElement(HotelBookingConstants.DONE_XPATH);
        webUi.assertIsVisibleText(page, HotelBookingConstants.BOOK_HOTELS_HOMESTAYS_TEXT);
        webUi.clickWebElement(HotelBookingConstants.SEARCH_XPATH);
        Page popupPage = webUi.waitForPopupAndClick(HotelBookingConstants.SEARCH_HOTEL_XPATH);
        webUi.clickByText(popupPage, HotelBookingConstants.VIEW_COMBO_TEXT);
        webUi.clickByText(popupPage, HotelBookingConstants.SELECT_COMBO_TEXT);
        webUi.clickAndFillText(popupPage, HotelBookingConstants.FIRST_NAME_XPATH, name);
        webUi.clickAndFillText(popupPage, HotelBookingConstants.LAST_NAME_XPATH, lname);
        webUi.clickAndFillText(popupPage, HotelBookingConstants.ENTER_EMAIL_XPATH, email);
        webUi.clickAndFillText(popupPage, HotelBookingConstants.ENTER_PHONE_NUMBER_XPATH, mobile);
    	webUi.assertIsVisibleText(popupPage, HotelBookingConstants.PRICE_SUMMARY_TEXT);
        webUi.clickWebElement(popupPage.locator(HotelBookingConstants.CONFIRM_SAVE_XPATH), HotelBookingConstants.CONFIRM_SAVE_XPATH);
    	webUi.assertIsVisibleText(popupPage, HotelBookingConstants.PROCEED_PAYMENT_OPTIONS_TEXT);
        webUi.clickWebElement(popupPage.locator(HotelBookingConstants.PROCEED_PAYMENT_XPATH), HotelBookingConstants.PROCEED_PAYMENT_XPATH);
        webUi.waitForTimeout(GlobalConstants.FIVE_SEC_WAIT);
    } 
}

