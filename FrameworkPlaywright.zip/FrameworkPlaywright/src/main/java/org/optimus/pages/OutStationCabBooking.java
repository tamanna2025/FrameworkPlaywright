package org.optimus.pages;


import com.microsoft.playwright.Page;
import com.optimus.constants.GlobalConstants;
import com.optimus.constants.MobileConstants;
import com.optimus.constants.OutStationCabConstants;
import com.optimus.constants.SearchProductConstants;

import io.qameta.allure.Step;
import org.optimus.utilities.WebUI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class OutStationCabBooking {
	
	private static final Logger log = LoggerFactory.getLogger(OutStationCabBooking.class);
    private final Page page;
    private WebUI webUi;
    
    public OutStationCabBooking(Page page) {
    	this.page = page;
        this.webUi = new WebUI(page);
    }
    @Step("<ul><li>1. Redirect to 'cab'" + "<ul><li>2. Select 'Pickup and drop' location"+ "<ul><li>3. Add one stop 'chandigarh'"
	        + "<ul><li>3.Click on 'SEARCH CAB' button" + "+</ul>")
	public void cabSelect(String pickUp, String dropOff, String enterStop, String name, String mobile, String email){
	
    	log.info(OutStationCabConstants.LOG_NAVIGATING_TO_GOIBIBO);
    	webUi.clickWebElement(OutStationCabConstants.CLOSE_XPATH);
    	webUi.clickWebElement(OutStationCabConstants.CAB_XPATH);
    	webUi.clickWebElement(OutStationCabConstants.PICKUP_XPATH);
    	webUi.fillText(page.locator(OutStationCabConstants.PICKUP_AREA_XPATH), pickUp);
    	webUi.clickWebElement(OutStationCabConstants.NOIDA_XPATH);
    	webUi.clickWebElement(OutStationCabConstants.DROP_XPATH);
    	webUi.assertIsVisibleText(page, OutStationCabConstants.BOOK_ONLINE_CAB_TEXT);
    	webUi.fillText(page.locator(OutStationCabConstants.DROP_AREA_XPATH), dropOff);
    	webUi.clickWebElement(OutStationCabConstants.ASR_XPATH);
    	webUi.clickWebElement(OutStationCabConstants.ADD_STOP_XPATH);
    	webUi.clickWebElement(OutStationCabConstants.ENTER_STOP_ONE_XPATH);
    	webUi.fillText(page.locator(OutStationCabConstants.ENTER_STOP_ONE_XPATH), enterStop);
    	webUi.clickWebElement(OutStationCabConstants.CHANDIGARH_XPATH);
//    	page.pause();
    	webUi.assertIsVisibleText(page, OutStationCabConstants.SEARCH_CAB_TEXT);
    	webUi.clickWebElement(OutStationCabConstants.SEARCH_CAB_XPATH);
    	webUi.clickWebElement(OutStationCabConstants.UPDATE_SEARCH_XPATH);
    	webUi.clickWebElement(OutStationCabConstants.SELECT_CAB_XPATH);
    	webUi.clickAndFillText(page, OutStationCabConstants.ENTER_NAME_XPATH, name);
    	webUi.clickAndFillText(page, OutStationCabConstants.ENTER_MOBILE_NUMBER_XPATH, mobile);
    	webUi.clickAndFillText(page, OutStationCabConstants.ENTER_EMAIL_XPATH, email);
    	webUi.assertIsVisibleText(page, OutStationCabConstants.TRAVELLER_DETAILS_TEXT);
    	webUi.clickWebElement(OutStationCabConstants.PROCEED_TO_PAY_XPATH);
    	webUi.assertIsVisibleText(page, OutStationCabConstants.GRAND_TOTAL_TEXT);
    	webUi.waitForTimeout(GlobalConstants.FIVE_SEC_WAIT);
    }
}
