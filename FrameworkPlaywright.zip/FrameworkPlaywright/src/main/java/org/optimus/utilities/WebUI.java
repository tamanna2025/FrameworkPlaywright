package org.optimus.utilities;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.TimeoutError;
import com.optimus.constants.GlobalConstants;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WebUI {
    private static final Logger log = LoggerFactory.getLogger(WebUI.class);
    private final Page page;

    public WebUI(Page page) {
        this.page = page;
    }
    /**
     * Waits for a specified amount of time in milliseconds.
     * 
     * @param milliseconds: The time to wait in milliseconds.
     */
    public void waitForTimeout(int milliseconds) {
        page.waitForTimeout(milliseconds);
    }
    /**
     * Click on the input element
     * 
     * @param selector: address to identify the element on web page
     */
    public void clickWebElement(String selector) {
        log.info(GlobalConstants.LOG_MSG_CLICKING + selector);
        Locator locator = page.locator(selector);

        try {
        	waitForTimeout(GlobalConstants.ONE_SEC_WAIT);
            locator.click();
        } catch (TimeoutError e) {
            throw new AssertionError(GlobalConstants.LOG_MSG_ASSERTION_FAILED, e);
        } catch (Exception exception) {
            throw new AssertionError(GlobalConstants.LOG_MSG_ASSERTION_FAILED, exception);
        }
    }
    
    public void clickWebElement(Locator locator, String selector) {
        log.info(GlobalConstants.LOG_MSG_CLICKING + selector); 
        try {
            waitForTimeout(GlobalConstants.ONE_SEC_WAIT);
            locator.scrollIntoViewIfNeeded(); 
            log.info(GlobalConstants.LOG_MSG_SCROLLING+ selector);
            locator.click(new Locator.ClickOptions().setTimeout(GlobalConstants.FIVE_SEC_WAIT));
        } catch (TimeoutError e) {
            throw new AssertionError(GlobalConstants.LOG_MSG_ASSERTION_FAILED, e);
        } catch (Exception exception) {
            throw new AssertionError(GlobalConstants.LOG_MSG_ASSERTION_FAILED, exception);
        }
    }

    
    /**
    * Waits for a popup to open after clicking on the specified element.
    *
    * @param selector: The locator for the element to click that opens the popup.
    * @return The newly opened Page object for the popup.
    */
   public Page waitForPopupAndClick(String selector) {
       // Use waitForPopup to wait for the popup while clicking the element
       return page.waitForPopup(() -> {
           page.locator(selector).click(); // Click the specified element
           page.waitForTimeout(GlobalConstants.TWO_SEC_WAIT); // Optional: wait for a short time
       });
   }
   
   /**
    * Interact with an element in the popup page.
    *
    * @param popupPage: The Page object of the popup.
    * @param locator: The locator for the element in the popup.
    */
   public void interactWithPopup(Page popupPage, String locator) {
       popupPage.waitForLoadState(); 
       popupPage.locator(locator).click(); 
   }
   
   /**
    * Scrolls the specified locator into view if needed.
    *
    * @param locator The locator of the element to scroll into view.
    */
   public void scrollIntoViewIfNeeded(Locator locator) {
       locator.scrollIntoViewIfNeeded();
       log.info(GlobalConstants.LOG_MSG_SCROLLING+ locator);
   }
   
   public void fillText(Locator locator, String text) {
       log.info(GlobalConstants.LOG_MSG_ENTERING_TEXT + GlobalConstants.LOG_MSG_COLON + text);
	   locator.fill(text);
   }
   
   public void clickAndFillText(Locator locator, String text) {
	    try {
	        log.info(GlobalConstants.LOG_MSG_CLICKING + GlobalConstants.LOG_MSG_COLON + locator.toString());
	        locator.click();
	        log.info(GlobalConstants.LOG_MSG_ENTERING_TEXT + GlobalConstants.LOG_MSG_COLON + text);
	        locator.fill(text);
	    } catch (Exception e) {
	        log.error( GlobalConstants.LOG_MSG_CLICKING_FILLING + e.getMessage(), e);
	    }
	}
 
   public void clickAndFillText(Page page, String selector, String text) {
       try {
    	   log.info(GlobalConstants.LOG_MSG_CLICKING  + selector);
           page.click(selector);
           log.info(GlobalConstants.LOG_MSG_ENTERING_TEXT + GlobalConstants.LOG_MSG_COLON + text);
           page.fill(selector, text); 
       } catch (Exception e) {
    	   log.error(GlobalConstants.LOG_MSG_CLICKING_FILLING  + e.getMessage());
       }
   }

   
   public void clickPlaceholder(Page context, String placeholder) {
	    log.info( GlobalConstants.LOG_MSG_CLICKING_PLACEHOLDER + placeholder);
	    context.getByPlaceholder(placeholder).click();
	}


   public void fillPlaceholder(Page context,String placeholder, String text) {
       log.info(GlobalConstants.LOG_MSG_FILLING_TEXT + text);
       context.getByPlaceholder(placeholder).fill(text);
   }

   public void pressEnter(String placeholder) {
       log.info(GlobalConstants.LOG_MSG_PRESS_ENTER_TEXT + placeholder);
       page.getByPlaceholder(placeholder).press("Enter");
   }
   public void clickByText(Page context, String text) {
       log.info(GlobalConstants.LOG_MSG_CLICKING_TEXT + text);
       try {
           context.getByText(text).click();
           log.info(GlobalConstants.LOG_MSG_CLICKED_TEXT);
       } catch (Exception e) {
           log.error(GlobalConstants.LOG_MSG_ERROR_CLICKING_TEXT + e.getMessage());
       }
   }
   public void assertIsVisibleText(Page context, String text) {
	   	log.info(GlobalConstants.LOG_MSG_ASSERT_PRESENCE + text);
	    assertThat(context.getByText(text)).isVisible();
	}
   
}
