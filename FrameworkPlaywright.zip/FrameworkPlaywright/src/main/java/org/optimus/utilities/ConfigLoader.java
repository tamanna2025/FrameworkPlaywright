package org.optimus.utilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigLoader {
    public static Properties properties = new Properties();

	public static String configLoader1(String configFilePath, String Key) {
    	String value = null;
        try (FileInputStream input = new FileInputStream(configFilePath)) {
            properties.load(input);
            value = properties.getProperty(Key);
        } catch (IOException e) {
            e.printStackTrace();
        } 
            return value;
    }
}
