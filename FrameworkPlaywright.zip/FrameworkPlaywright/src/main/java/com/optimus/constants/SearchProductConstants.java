package com.optimus.constants;

public class SearchProductConstants {

	/**
     * public class Search Product for Web
     */
	
	/**
     * Search Product WebElements Locators
     */
	public static final String SEARCH_PRODUCT_PLACEHOLDER = "Search for Products, Brands";

	public static final String IPHONE_XPATH = "//div[text()=\"Apple iPhone 16 (Teal, 128 GB)\"]";
	
	public static final String ENTER_DELIVERY_PINCODE_XPATH =  "//button[text()=\"Enter Delivery Pincode\"]";
	
	public static final String ENTER_PINCODE_PLACEHOLDER = "Enter pincode";
	
	public static final String NEWEST_FIRST_TEXT = "Newest First";
	
	public static final String SUBMIT_TEXT = "Submit";
	
	public static final String TARN_TARAN_TEXT = "Tarn Taran -";
	
	public static final String APPLE_IPHONE_TEXT = "Apple iPhone 16 (Teal, 128 GB)";

	
	//log messages
	
	public static final String LOG_MSG_IPHONE_SELECTION_TEXT = "iPhone successfully added to cart";
}
