package com.optimus.constants;

public class HotelBookingConstants {
	/**
     * Test Data
     */
    public static final String TEST_DATA_CITY = "city";
    
    public static final String TEST_DATA_LAST_NAME = "lastName";
    
    /**
     * location WebElements Locators
     */
    public static final String HOTELS_XPATH = "//span[text()=\"Hotels\"]";
    
    public static final String INDIA_XPATH = "//h4[text()=\"India\"]";
    
    public static final String SEARCH_CITY_XPATH = "//input[@placeholder=\"e.g. - Area, Landmark or Property Name\"]";
    
    public static final String GUEST_ROOMS_XPATH = "//span[text()=\"Guests & Rooms\"]/following::input";
    
    public static final String ADD_ROOM_XPATH = "//h4[@data-testid=\"room-count\"]//following-sibling::span";
    
    public static final String ADD_ADULT_XPATH = "//h4[@data-testid=\"adult-count\"]//following-sibling::span";
    
    public static final String ADD_CHILD_XPATH = "//h4[@data-testid=\"child-count\"]//following-sibling::span";
    
    public static final String SELECT_XPATH = "//h4[text()=\"Select\"]";
    
    public static final String CHILD_AGE_XPATH = "//ul/li[text()=\"1\"]";
    
    public static final String DONE_XPATH = "//button[text()=\"Done\"]";
    
    public static final String SEARCH_XPATH = "//button[text()=\"Search\"]";
    
    public static final String DROP_SELECT_XPATH = "//*[@id=\"downshift-1-menu\"]"; 
    
    public static final String SEARCH_HOTEL_XPATH = "//p[text()=\"Filter Properties based on area/landmark of your choice\"]//following::div[85]";
    
    public static final String SELECT_HOTEL_XPATH = "//button[@data-testid=\"selectRoomBtn\"]";
    
    public static final String FIRST_NAME_XPATH = "//input[@placeholder='Enter First Name']";
    
    public static final String LAST_NAME_XPATH = "//input[@placeholder='Enter Last Name']";
    
    public static final String ENTER_EMAIL_XPATH = "//input[@placeholder='Enter Email Address']";
    
    public static final String ENTER_PHONE_NUMBER_XPATH ="//input[@placeholder='Enter Phone Number']";
    
    public static final String PROCEED_PAYMENT_XPATH ="//span[text()='Proceed To Payment Options']";
    
    public static final String CONFIRM_SAVE_XPATH ="//label[text()='Confirm and save billing details to your profile']";
    
    public static final String VIEW_COMBO_TEXT = "View this Combo";
    
    public static final String SELECT_COMBO_TEXT = "SELECT COMBO";
    
    public static final String PRICE_SUMMARY_TEXT = "Price Summary";
    
    public static final String PROCEED_PAYMENT_OPTIONS_TEXT = "Proceed To Payment Options";
    
    public static final String BOOK_HOTELS_HOMESTAYS_TEXT = "Book Hotels & Homestays";
    
    public static final String GUESTS_AND_ROOMS_TEXT = "Guests & Rooms";
    /**
     * log Messages
     */
    public static final String LOG_MSG_OPEN_SUCCESS = "Hotel Booking opened successfully";
    
    public static final String LOG_ERROR_FAILED_TO_SELECT_HOTEL = "Hotel selection failed";
}
