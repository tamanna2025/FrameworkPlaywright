package com.optimus.constants;

public class MobileConstants {
	
	/**
     * public class MobileConstant for Web
     */
	
	/**
     * Mobile WebElements Locators
     */
	
	public static final String ELECTRONICS_XPATH = "//span[text()=\"Electronics\"]";
	
    public static final String MI_XPATH = "//a[@title=\"Mi\"]";
    
    public static final String PHONE_XPATH = "//div[text()=\"Xiaomi 14 CIVI (Shadow Black, 256 GB)\"]";
    
    public static final String PINCODE_ID = "#pincodeInputId";
    
    public static final String ADD_TO_CART_XPATH = "//button[text()=\"Add to cart\"]";
    
    public static final String PINCODE_TEXT = "//input[@placeholder=\"Enter Delivery Pincode\"]";
    
    
    //Log Messages
    
    public static final String LOG_MSG_NAVIGATING = "Navigating to flipkart";
    
    public static final String LOG_MSG_PIN_VISIBLE = "Checking if the PIN code field is visible.";
    
    public static final String LOG_MSG_ASSERTION_PASSED_PIN = "Assertion passed: PIN code field is visible.";
    
    public static final String LOG_MSG_MOBILE_SELECTION_TEXT = "Mobile selection successful with pin";
    
    public static final String LOG_MSG_TEST_FAILED_TEXT = "Test failed due to an exception: {}";
    
    public static final String LOG_MSG_MOBILE_VISIBLE = "Checking if the desired mobile is visible.";
    
    public static final String LOG_MSG_ASSERTION_PASSED_MOBILE = "Assertion passed: Desired Mobile is visible.";
    
    //Error Messages
    
    public static final String PINCODE_BLANK = "Pin cannot be null or empty";
    

    //Path for properties file 
	
	public static final String PATH = "src\\main\\resources\\config.properties";

}