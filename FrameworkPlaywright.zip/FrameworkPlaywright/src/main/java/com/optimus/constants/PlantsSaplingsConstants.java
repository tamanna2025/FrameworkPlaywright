package com.optimus.constants;

public class PlantsSaplingsConstants {

	/**
     * public class PlantsSaplingsConstants for Web
     */
	
	/**
     * Plants Saplings WebElements Locators
     */
	
	public static final String HOME_KITCHEN_TEXT = "Home & Kitchen";
	
	public static final String HOME_FURNITURE_TEXT = "Home & Furniture";
	
	public static final String LAWN_GARDENING_TEXT = "Lawn & Gardening";
	
	public static final String PLANTS_PLANTERS_TEXT = "Plants and Planters";
	
	public static final String PLANTS_SAPLINGS_XPATH = "//a[@title=\"Plants Saplings\"]";
	
	public static final String HIGH_TO_LOW_TEXT = "//div[text()='Price -- High to Low']";
	
	public static final String FIRST_TOP_PLANT_XPATH = "//div[text()=\"Newest First\"]//following::div[3]";


	public static final String SAVE_FOR_LATER_TEXT = "Save for later";
	
	public static final String MOBILES_XPATH = "//span[text()=\"Mobiles\"]";
	
	//log messages
	
	public static final String LOG_MSG_PLANT_SELECTED = "Plant is selected successfully";
	
}
