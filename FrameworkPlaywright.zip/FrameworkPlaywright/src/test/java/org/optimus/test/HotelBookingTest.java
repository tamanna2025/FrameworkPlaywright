package org.optimus.test;

import org.optimus.base.BaseWebTest;
import org.optimus.pages.HotelBooking;
import org.optimus.utilities.ConfigLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import com.optimus.constants.HotelBookingConstants;
import com.optimus.constants.MobileConstants;

import io.qameta.allure.Description;

public class HotelBookingTest extends BaseWebTest {
    private static final Logger log = LoggerFactory.getLogger(HotelBookingTest.class);
    private String hotelCity;
    private String lname;
    private String name;
    private String mobile;
    private String email;
    
    private HotelBooking hotelBooking;
    @Description("Verify user is able to select Hotel")
    @Test(description = "Verify user is able to select Hotel", priority = 1)
    public void verifyCab() {
        String configPath = MobileConstants.PATH;
        hotelCity = ConfigLoader.configLoader1(configPath, "hotelCity");
        lname = ConfigLoader.configLoader1(configPath, "lname");
        name = ConfigLoader.configLoader1(configPath, "name");
        mobile = ConfigLoader.configLoader1(configPath, "mobile");
        email = ConfigLoader.configLoader1(configPath, "email");
        hotelBooking = new HotelBooking(page);

        try {
        	hotelBooking.hotelSelect(hotelCity,name,lname,email,mobile);
	        log.info(HotelBookingConstants.LOG_MSG_OPEN_SUCCESS);
        } catch (Exception exception) {
            log.error(HotelBookingConstants.LOG_ERROR_FAILED_TO_SELECT_HOTEL, exception.getMessage());
            throw exception;
        }
    }
}
