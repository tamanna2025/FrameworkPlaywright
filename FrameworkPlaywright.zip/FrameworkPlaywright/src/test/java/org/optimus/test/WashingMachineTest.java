package org.optimus.test;

import org.optimus.base.BaseWebTest;
import org.optimus.pages.WashingMachine;
import org.testng.annotations.Test;
import com.optimus.constants.MobileConstants;
import com.optimus.constants.WashingMachineConstants;

import io.qameta.allure.Description;
import io.qameta.allure.Epic;
import io.qameta.allure.Feature;
import io.qameta.allure.Story;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WashingMachineTest extends BaseWebTest {
    private static final Logger log = LoggerFactory.getLogger(WashingMachineTest.class);
    @Epic("Behavior Test for Washing Machine addition to Cart")
    @Feature("Adding Washing Machine to cart")
    @Story("Washing Machine Story")
    @Description("Verify that LG Washing machine is getting added to the cart successfully")
    @Test(description = "Verify that LG Washing machine is getting added to the cart successfully", priority = 1)
    public void verifyWashingMachine() {
        WashingMachine washingMachine = new WashingMachine(page);
        try {
            washingMachine.washingMachineSelect();
            log.info(WashingMachineConstants.LOG_MSG_WASHING_MACHINE_SELECTED);
        } catch (Exception exception) {
            log.error(MobileConstants.LOG_MSG_TEST_FAILED_TEXT, exception.getMessage());
            throw exception;
        }
    }
}
