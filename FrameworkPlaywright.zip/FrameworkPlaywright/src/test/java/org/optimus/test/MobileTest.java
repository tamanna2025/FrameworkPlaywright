package org.optimus.test;

import org.optimus.base.BaseWebTest;
import org.optimus.pages.MobilePage;
import org.optimus.utilities.ConfigLoader;
import org.testng.annotations.Test;
import com.optimus.constants.MobileConstants;

import io.qameta.allure.Description;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MobileTest extends BaseWebTest {
    private static final Logger log = LoggerFactory.getLogger(MobileTest.class);
    
    @Description("Verify that Mi mobile is getting added to the cart successfully")
    @Test(description = "Verify that Mi mobile is getting added to the cart successfully", priority = 1)
    public void verifyMobile() {
        String configPath = MobileConstants.PATH;
        String pin = ConfigLoader.configLoader1(configPath, "pin");
        MobilePage mobilePage = new MobilePage(page);
        
        try {
            if (pin == null || pin.isEmpty()) {
                throw new IllegalArgumentException(MobileConstants.PINCODE_BLANK);
            }
            mobilePage.mobileSelect(pin);
            log.info(MobileConstants.LOG_MSG_MOBILE_SELECTION_TEXT, pin);
        } catch (Exception exception) {
            log.error(MobileConstants.LOG_MSG_TEST_FAILED_TEXT, exception.getMessage());
            throw exception;
        }
    }
}
