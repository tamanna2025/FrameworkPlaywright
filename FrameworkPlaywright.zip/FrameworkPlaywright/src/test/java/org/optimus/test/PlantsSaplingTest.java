package org.optimus.test;

import org.optimus.base.BaseWebTest;
import org.optimus.pages.PlantsSaplings;
import org.testng.annotations.Test;
import com.optimus.constants.MobileConstants;
import com.optimus.constants.PlantsSaplingsConstants;

import io.qameta.allure.Description;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PlantsSaplingTest extends BaseWebTest {
    private static final Logger log = LoggerFactory.getLogger(PlantsSaplingTest.class);
    
    @Description("Verify that Plant is getting added to the cart successfully")
    @Test(description = "Verify that Plant is getting added to the cart successfully", priority = 1)
    public void verifyPlantSapling() {
        PlantsSaplings plantsSaplings = new PlantsSaplings(page);
        try {
        	plantsSaplings.plantSelect();
            log.info(PlantsSaplingsConstants.LOG_MSG_PLANT_SELECTED);
        } catch (Exception exception) {
            log.error(MobileConstants.LOG_MSG_TEST_FAILED_TEXT, exception.getMessage());
            throw exception;
        }
    }
}
